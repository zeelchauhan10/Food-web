import React from 'react'

export const Gujjubiteimg = () => {
    return (
        <>
            <div className='row logo text-center  mx-auto mb-3 pt-5 pb-3 ' style={{background: "transparent"}}>
                <div className='col-10 col-md-5 mx-auto' style={{background: "transparent"}}>
                    <img src="./imges/gujju_logo.png" className='img-fluid' style={{background: "transparent"}}/>
                </div>
            </div>
            {/* <hr /> */}

        </>
    )
}
