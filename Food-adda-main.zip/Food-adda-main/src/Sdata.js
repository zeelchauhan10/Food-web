const Sdata = [
    {
        id: 1,
        img: "imges/maggy.jpg",
        name: "MAGGI",
        price: 20,
        category: "evening",
        quntity:1
    },
    {
        id: 2,
        img: "imges/allupakoda.jpg",
        name: "ALLU PAKODA",
        price: 40,
        category: "dinner",
        quntity:1
    },
    {
        id: 3,
        img: "imges/dabeli.jpg",
        name: "DABELI",
        price: 25,
        category: "evening",
        quntity:1
    },
    {
        id: 4,
        img: "imges/gathiya.jpg",
        name: "GADHIYA",
        price: 30,
        category: "breakfast",
        quntity:1
    },
    {
        id: 5,
        img: "imges/pizza.jpg",
        name: "PIZZA",
        price: 200,
        category: "evening",
        quntity:1
    },
    {
        id: 6,
        img: "imges/samosa.jpg",
        name: "SAMASO",
        price: 50,
        category: "dinner",
        quntity:1
    },
    {
        id: 7,
        img: "imges/chokomilk.jpg",
        name: "Choko-Milk",
        price: 40,
        category: "dinner",
        quntity:1
    },
    {
        id: 8,
        img: "imges/cola.jpg",
        name: "Coco-Cola",
        price: 30,
        category: "dinner",
        quntity:1
    },
    {
        id: 9,
        img: "imges/dhokla.jpg",
        name: "Dhokla",
        price: 40,
        category: "dinner",
        quntity:1
    },
    {
        id: 10,
        img: "imges/dhosa.jpg",
        name: "Dhosa",
        price: 80,
        category: "dinner",
        quntity:1
    },
    {
        id: 11,
        img: "imges/idli.jpg",
        name: "Idli",
        price: 50,
        category: "dinner",
        quntity:1
    },
    {
        id: 12,
        img: "imges/jalebi.jpg",
        name: "Jalebi",
        price: 60,
        category: "dinner",
        quntity:1
    },
    {
        id: 13,
        img: "imges/jamun.jpg",
        name: "Gulab-Jamun",
        price: 60,
        category: "dinner",
        quntity:1
    },
    {
        id: 14,
        img: "imges/maza.jpg",
        name: "Maaza",
        price: 60,
        category: "dinner",
        quntity:1
    },
    {
        id: 15,
        img: "imges/rasgulla.jpg",
        name: "RasGulla",
        price: 60,
        category: "dinner",
        quntity:1
    },
    
    



]

export default Sdata;